from __future__ import annotations

import asyncio
import errno
import hashlib
import importlib
import inspect
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, replace
from typing import Any, Literal, TypeVar

from openai_codex import JsonRpcError, MethodNotFoundError, TransportClosedError
from openai_codex.generated.v2_all import (
    ApprovalsReviewer,
    AskForApproval,
    AskForApprovalValue,
    DangerFullAccessSandboxPolicy,
    LocalImageUserInput,
    ReadOnlySandboxPolicy,
    ReasoningEffort,
    SandboxMode,
    SandboxPolicy,
    SortDirection,
    TextUserInput,
    ThreadResumeParams,
    ThreadSortKey,
    ThreadStartParams,
    TurnStartParams,
    UserInput,
    WorkspaceWriteSandboxPolicy,
)
from pydantic import BaseModel, ConfigDict, Field

from connector.logging import logger
from connector.runtime_protocol import (
    RuntimeConfig,
    RuntimeConflictError,
    RuntimeInvalidRequestError,
)
from connector.runtimes.codex.domain.input_requests import CODEX_REQUEST_USER_INPUT
from connector.runtimes.codex.domain.selections import permission_profile_id
from connector.runtimes.codex.runtime_helpers import soft_codex_unavailable_reason
from connector.runtimes.codex.sdk.binary import (
    codex_launch_command,
    codex_runtime_environment,
    select_codex_runtime_binary,
)
from connector.runtimes.codex.sdk.command_notifications import (
    CommandNotifications,
    LowLevelTurnHandle,
    turn_identity,
)
from connector.runtimes.codex.sdk.events import CodexSdkEvent
from connector.runtimes.codex.sdk.model_gateway import (
    CODEX_MODEL_GATEWAY_PROVIDER_ID,
    codex_model_gateway_config,
)
from connector.runtimes.codex.sdk.runtime_client import (
    CodexCompactResult,
    CodexInterruptTurnRequest,
    CodexModelListResult,
    CodexNotificationMessage,
    CodexResumeThreadRequest,
    CodexRuntimeClient,
    CodexStartThreadRequest,
    CodexStartTurnRequest,
    CodexSteerTurnRequest,
    CodexThreadListResult,
    CodexThreadReadResult,
    CodexThreadResult,
    CodexThreadTurnsPage,
    CodexThreadTurnsResult,
    CodexTurnResult,
    NotificationHandler,
)
from connector.runtimes.codex.sdk.server_requests import (
    install_deferred_server_request_reader,
)
from connector.runtimes.codex.sdk.shapes import (
    call_with_optional_handler,
    compact_result,
    id_of,
    maybe_await,
    model_list_result,
    sdk_approval_mode,
    sdk_sandbox,
    thread_list_result,
    thread_read_result,
    thread_ref,
    turn_action_result,
    turn_ref,
)
from connector.runtimes.model_gateway import ModelGateway, model_gateway_from_config

CodexApprovalSettings = tuple[AskForApproval | None, ApprovalsReviewer | None]
CODEX_SDK_APPROVAL_REQUEST_METHODS = {
    "item/commandExecution/requestApproval",
    "item/fileChange/requestApproval",
    "item/permissions/requestApproval",
}
CODEX_SDK_INPUT_REQUEST_METHODS = {CODEX_REQUEST_USER_INPUT}
CODEX_THREAD_TURNS_PAGE_SIZE = 100
ReadResultT = TypeVar("ReadResultT")


@dataclass(frozen=True, slots=True)
class PendingServerRequest:
    kind: Literal["approval", "input"]
    response: asyncio.Future[Mapping[str, Any]]

    def cancel(self) -> None:
        if not self.response.done():
            self.response.set_result(
                {"answers": {}} if self.kind == "input" else {"decision": "decline"}
            )


@dataclass(slots=True)
class TurnStreamState:
    thread_id: str
    turn_id: str
    terminal_delivery: asyncio.Task[None] | None = None


class CodexThreadTurnsListResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    data: list[dict[str, Any]]
    next_cursor: str | None = Field(default=None, alias="nextCursor")


class CodexPlanningResumeResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    thread: dict[str, Any]
    model: str
    reasoning_effort: str | None = Field(default=None, alias="reasoningEffort")
    collaboration_mode: dict | None = Field(default=None, alias="collaborationMode")


class CodexSettingsUpdateResponse(BaseModel):
    """``thread/settings/update`` and ``turn/settings/update`` answer ``{}``."""

    model_config = ConfigDict(extra="allow")


class CodexRawThreadReadResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    thread: dict[str, Any]


class CodexSdkClient:
    """Adapter from the Codex SDK client shape to the runtime client protocol.

    The connector runtime wants a tiny async JSON-RPC-like surface. Keeping the
    SDK-specific discovery here lets `CodexRuntime` stay protocol-oriented.
    """

    def __init__(
        self,
        client: Any,
        sdk: Any | None = None,
        model_gateway: ModelGateway | None = None,
        client_factory: Callable[[], Any] | None = None,
    ) -> None:
        self._client = client
        self._sdk = sdk
        self._model_gateway = model_gateway
        self._client_factory = client_factory
        self._recovery_lock = asyncio.Lock()
        self._started = False
        self._handler: NotificationHandler | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        # Responses for blocking Codex server requests. Approvals and
        # `request_user_input` questionnaires share this pending map.
        self._pending_approval_responses: dict[str, PendingServerRequest] = {}
        self._entered_client: Any | None = None
        self._threads: dict[str, Any] = {}
        self._loaded_thread_ids: set[str] = set()
        self._thread_settings_update_supported = True
        self._turns: dict[str, Any] = {}
        self._stream_tasks: dict[str, asyncio.Task[None]] = {}
        self._stream_states: dict[str, TurnStreamState] = {}
        self._global_notification_task: asyncio.Task[None] | None = None
        self._command_notifications = CommandNotifications.for_client(client)
        self._generation = 0
        self._resume_locks: dict[str, asyncio.Lock] = {}
        self._announced_turns: set[tuple[str, str]] = set()
        self._stopping = False
        self._planning_modes: dict[str, dict] = {}
        self._thread_settings: dict[str, dict] = {}

    async def start(self, handler: NotificationHandler) -> None:
        self._stopping = False
        self._handler = handler
        self._loop = asyncio.get_running_loop()
        await self.start_native_client(self._client)
        self._started = True
        self.start_global_notification_task()

    async def start_native_client(self, client: Any) -> None:
        # Command notifications are routed through the SDK router of this
        # exact client, so a recovered transport needs a fresh router binding.
        self._command_notifications = CommandNotifications.for_client(client)
        observer = (
            self._command_notifications.route if self._command_notifications else None
        )
        if install_deferred_server_request_reader(client, observer):
            logger.debug("codex sdk deferred server request reader installed")
        install_codex_approval_handler(client, self.handle_sdk_approval_request)
        start = getattr(client, "start", None)
        if callable(start):
            await maybe_await(call_with_optional_handler(start, self._handler))
        elif hasattr(client, "__aenter__"):
            self._entered_client = await client.__aenter__()

    async def stop(self) -> None:
        self._started = False
        await self.finish_terminal_streams()
        # Nothing may reach the runtime once shutdown starts closing the
        # transport; streams woken by the close must not emit synthetic failures.
        self._stopping = True
        self._clear_native_ownership()
        await self.cancel_background_tasks(close_client=self._client)

    async def finish_terminal_streams(self) -> None:
        """Let turns already delivering a terminal finish on the live transport.

        Such a stream is parked on its delivery, outside the SDK read, so it can
        be cancelled without orphaning the SDK worker behind its queue.
        """
        for stream in tuple(self._stream_states.values()):
            if stream.terminal_delivery is None:
                continue
            task = self._stream_tasks.get(stream.turn_id)
            if task is not None:
                task.cancel()
            await self._finish_terminal_delivery(stream)

    async def cancel_background_tasks(
        self,
        *,
        transport_failed: bool = False,
        close_client: Any | None = None,
    ) -> None:
        interrupted_streams = tuple(self._stream_states.values())
        self.cancel_pending_approval_responses()
        if self._global_notification_task is not None:
            self._global_notification_task.cancel()
            await asyncio.gather(
                self._global_notification_task,
                return_exceptions=True,
            )
            self._global_notification_task = None
        stream_tasks = tuple(self._stream_tasks.values())
        try:
            # Closing the transport wakes SDK workers before a cancelled stream
            # can unregister their queues. asyncio cancellation alone cannot
            # stop the older SDK's blocking queue.get worker.
            if close_client is not None:
                await self.stop_native_client(close_client)
        finally:
            for task in stream_tasks:
                task.cancel()
            await asyncio.gather(*stream_tasks, return_exceptions=True)
            self._stream_tasks.clear()
        for stream in interrupted_streams:
            if stream.terminal_delivery is None and transport_failed:
                # Only a turn without a terminal owner needs a synthetic failure.
                # An in-flight terminal must finish its notices and state first.
                self._start_terminal_delivery(
                    stream,
                    {
                        "method": "turn/failed",
                        "params": {
                            "threadId": stream.thread_id,
                            "turnId": stream.turn_id,
                            "error": {
                                "code": "codex_transport_closed",
                                "message": "Codex connection closed while this turn was active.",
                            },
                            "metadata": {"source": "codex.sdk.transport.recovery"},
                        },
                    },
                )
            await self._finish_terminal_delivery(stream)
        self._stream_states.clear()
        self._clear_native_ownership()

    async def stop_native_client(self, client: Any) -> None:
        stop = getattr(client, "stop", None)
        if callable(stop):
            await maybe_await(stop())
        elif self._entered_client is not None and hasattr(client, "__aexit__"):
            await client.__aexit__(None, None, None)
            self._entered_client = None
        elif hasattr(client, "close"):
            await maybe_await(client.close())

    async def call_read_with_recovery(
        self,
        operation: str,
        action: Callable[[Any], Awaitable[ReadResultT]],
    ) -> ReadResultT:
        failed_client = self._client
        try:
            return await action(failed_client)
        except Exception as exc:
            if not is_codex_transport_closed_error(exc):
                raise
            await self.recover_transport(
                operation=operation,
                failed_client=failed_client,
                error=exc,
            )
        return await action(self._client)

    async def recover_transport(
        self,
        *,
        operation: str,
        failed_client: Any,
        error: Exception,
    ) -> None:
        if self._client_factory is None:
            raise error
        async with self._recovery_lock:
            if self._client is not failed_client:
                return
            logger.warning(
                "codex sdk transport closed; recreating app-server "
                "operation={} error_type={}",
                operation,
                type(error).__name__,
            )
            await self.cancel_background_tasks(transport_failed=True)
            try:
                await self.stop_native_client(failed_client)
            except Exception as stop_error:  # noqa: BLE001
                logger.debug(
                    "codex sdk failed client cleanup skipped error_type={}",
                    type(stop_error).__name__,
                )
            replacement = self._client_factory()
            self._client = replacement
            self._entered_client = None
            if self._started:
                await self.start_native_client(replacement)
                self.start_global_notification_task()
            logger.info(
                "codex sdk transport recovered operation={} error_type={}",
                operation,
                type(error).__name__,
            )

    def cancel_pending_approval_responses(self) -> None:
        pending = tuple(self._pending_approval_responses.values())
        self._pending_approval_responses.clear()
        for request in pending:
            request.cancel()

    def start_global_notification_task(self) -> None:
        """Forward SDK global notifications to the runtime projector.

        Side effects:
        - starts one background task owned by this client
        - emits non-turn-scoped SDK notifications such as thread/compacted
        """

        next_notification = getattr(self._client, "next_notification", None)
        if not callable(next_notification):
            next_notification = getattr(
                getattr(self._client, "_client", None), "next_notification", None
            )
        if not callable(next_notification) or self._handler is None:
            return
        if self._global_notification_task is not None:
            return
        self._global_notification_task = asyncio.create_task(
            self.stream_global_notifications(next_notification)
        )
        self._global_notification_task.add_done_callback(
            self.handle_global_notification_task_done
        )

    def handle_global_notification_task_done(self, task: asyncio.Task[None]) -> None:
        if self._global_notification_task is task:
            self._global_notification_task = None
        try:
            task.result()
        except asyncio.CancelledError:
            logger.debug("codex sdk global notification task cancelled")
        except Exception:  # noqa: BLE001
            self._clear_native_ownership()
            logger.exception("codex sdk global notification task failed")

    def _clear_native_ownership(self) -> None:
        self._generation += 1
        self._loaded_thread_ids.clear()
        self._planning_modes.clear()
        self._thread_settings.clear()
        self._threads.clear()
        self._turns.clear()
        self._announced_turns.clear()
        if self._command_notifications:
            self._command_notifications.clear()

    async def stream_global_notifications(self, next_notification: Any) -> None:
        while True:
            notification = await maybe_await(next_notification())
            await self._emit(notification)

    async def list_models(self) -> CodexModelListResult:
        async def read_models(client: Any) -> Any:
            models = getattr(client, "models", None)
            if not callable(models):
                raise RuntimeInvalidRequestError(
                    "Codex SDK client does not expose models()"
                )
            return await models(include_hidden=False)

        result = await self.call_read_with_recovery("model/list", read_models)
        return model_list_result(result)

    async def list_threads(
        self,
        limit: int = 100,
        cursor: str | None = None,
        archived: bool | None = None,
    ) -> CodexThreadListResult:
        params: dict[str, Any] = {
            "cursor": cursor,
            "limit": limit,
            "model_providers": [],
            "sort_direction": SortDirection.desc,
            "sort_key": ThreadSortKey.recency_at,
        }
        if archived is not None:
            params["archived"] = archived

        async def read_threads(client: Any) -> Any:
            thread_list = getattr(client, "thread_list", None)
            if not callable(thread_list):
                raise RuntimeInvalidRequestError(
                    "Codex SDK client does not expose thread_list()"
                )
            return await thread_list(**params)

        result = await self.call_read_with_recovery("thread/list", read_threads)
        return thread_list_result(result)

    async def read_thread(
        self,
        thread_id: str,
        include_turns: bool = True,
    ) -> CodexThreadReadResult:
        started_at = time.monotonic()

        async def read(client: Any) -> CodexThreadReadResult:
            low_level_client = getattr(client, "_client", None)
            request = getattr(low_level_client, "request", None)
            if callable(request):
                await ensure_codex_initialized(client)
                result = await request(
                    "thread/read",
                    {"threadId": thread_id, "includeTurns": include_turns},
                    response_model=CodexRawThreadReadResponse,
                )
                return CodexThreadReadResult(thread=result.thread)
            thread = self._thread_handle(thread_id)
            result = await thread.read(include_turns=include_turns)
            return thread_read_result(result)

        projected = await self.call_read_with_recovery("thread/read", read)
        elapsed_ms = (time.monotonic() - started_at) * 1000
        if include_turns or elapsed_ms >= 250:
            logger.info(
                "codex sdk thread read completed thread_id={} include_turns={} elapsed_ms={:.1f}",
                thread_id,
                include_turns,
                elapsed_ms,
            )
        return projected

    async def list_thread_turns(self, thread_id: str) -> CodexThreadTurnsResult:
        turns_descending: list[Mapping[str, Any]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            page = await self.list_thread_turns_page(thread_id, cursor, CODEX_THREAD_TURNS_PAGE_SIZE)
            turns_descending.extend(page.turns)
            next_cursor = page.next_cursor
            if next_cursor is None:
                break
            if next_cursor in seen_cursors:
                raise RuntimeError(f"Codex history pagination repeated a cursor for {thread_id}")
            seen_cursors.add(next_cursor)
            cursor = next_cursor
        turns_descending.reverse()
        return CodexThreadTurnsResult(turns=tuple(turns_descending))

    async def list_thread_turns_page(
        self,
        thread_id: str,
        cursor: str | None = None,
        limit: int = 20,
    ) -> CodexThreadTurnsPage:
        params: dict[str, Any] = {
            "threadId": thread_id,
            "limit": limit,
            "sortDirection": "desc",
            "itemsView": "full",
        }
        if cursor is not None:
            params["cursor"] = cursor

        async def read_page(client: Any) -> Any:
            await ensure_codex_initialized(client)
            low_level_client = getattr(client, "_client", None)
            request = getattr(low_level_client, "request", None)
            if not callable(request):
                raise RuntimeInvalidRequestError(
                    "Codex SDK client does not expose raw request() for thread turns"
                )
            try:
                return await request(
                    "thread/turns/list",
                    params,
                    response_model=CodexThreadTurnsListResponse,
                )
            except MethodNotFoundError as exc:
                raise RuntimeInvalidRequestError(
                    "Codex app-server does not support thread/turns/list"
                ) from exc

        page = await self.call_read_with_recovery(
            "thread/turns/list",
            read_page,
        )
        return CodexThreadTurnsPage(turns=tuple(page.data), next_cursor=page.next_cursor)

    async def start_thread(self, request: CodexStartThreadRequest) -> CodexThreadResult:
        await ensure_codex_initialized(self._client)
        low_level_client = codex_low_level_client(self._client)
        if low_level_client is not None:
            generation = self._generation
            started = await low_level_client.thread_start(
                codex_permission_params(
                    codex_thread_start_params(request, self._model_gateway),
                    request.sandbox,
                    "sandbox",
                )
            )
            thread_id = id_of(started.thread)
            if thread_id:
                self._thread_settings[thread_id] = {"model": getattr(started, "model", request.model), "reasoning_effort": getattr(started, "reasoning_effort", None)}
            if generation != self._generation:
                raise RuntimeError("Codex disconnected while starting the thread")
            thread = codex_async_thread(self._sdk, self._client, thread_id)
            if thread is not None:
                self._remember_thread(thread)
            if thread_id is not None:
                self._loaded_thread_ids.add(thread_id)
            return CodexThreadResult(
                thread_id=thread_id,
                payload={"id": thread_id} if thread_id is not None else {},
            )
        if self._model_gateway is not None:
            raise RuntimeInvalidRequestError(
                "Codex low-level client is required for model gateway configuration"
            )
        if codex_request_requires_low_level_approval(request):
            raise RuntimeInvalidRequestError(
                "Codex low-level client is required for explicit approval settings"
            )

        thread_start = getattr(self._client, "thread_start", None)
        if not callable(thread_start):
            raise RuntimeInvalidRequestError(
                "Codex SDK client does not expose thread_start()"
            )
        thread = await thread_start(
            cwd=request.cwd,
            model=request.model,
            approval_mode=sdk_approval_mode(self._sdk, request.approval_policy),
            sandbox=sdk_sandbox(self._sdk, request.sandbox),
            ephemeral=request.ephemeral,
        )
        self._remember_thread(thread)
        thread_id = id_of(thread)
        if thread_id is not None:
            self._loaded_thread_ids.add(thread_id)
        payload = thread_ref(thread)
        return CodexThreadResult(thread_id=thread_id, payload=payload)

    async def start_turn(self, request: CodexStartTurnRequest) -> CodexTurnResult:
        if request.thread_id in self._planning_modes:
            collaboration = self._planning_modes[request.thread_id]
            settings = dict(collaboration.get("settings") or {})
            if request.model is not None:
                settings["model"] = request.model
            if request.effort is not None:
                settings["reasoning_effort"] = request.effort
            request = replace(request, collaboration_mode={**collaboration, "settings": settings})
        await ensure_codex_initialized(self._client)
        low_level_client = codex_low_level_client(self._client)
        if low_level_client is not None:
            await self.ensure_thread_resumed_for_turn(low_level_client, request)
            # Recovery may swap the router mid-call; finish on the one we began.
            notifications = self._command_notifications
            if notifications:
                notifications.begin_turn(request.thread_id)
            turn_id = None
            try:
                started = await self.start_low_level_turn_with_resume_retry(
                    low_level_client, request
                )
                turn_id = id_of(started.turn)
            finally:
                if notifications:
                    notifications.finish_turn(request.thread_id, turn_id)
            turn = codex_async_turn_handle(
                self._sdk,
                self._client,
                request.thread_id,
                turn_id,
            )
            if turn is not None:
                self._remember_turn(request.thread_id, turn)
            await self._emit(
                {
                    "method": "turn/started",
                    "params": {
                        "threadId": request.thread_id,
                        "turn": {"id": turn_id} if turn_id is not None else {},
                    },
                }
            )
            if turn is not None:
                self._start_stream_task(request.thread_id, turn)
            return CodexTurnResult(
                turn_id=turn_id,
                payload={"id": turn_id} if turn_id is not None else {},
            )
        if codex_request_requires_low_level_turn_start(request):
            raise RuntimeInvalidRequestError(
                codex_low_level_turn_start_required_message(request)
            )

        thread = self._thread_handle(request.thread_id)
        turn = await thread.turn(
            codex_high_level_turn_content(request),
            model=request.model,
            effort=request.effort,
            approval_mode=sdk_approval_mode(self._sdk, request.approval_policy),
            sandbox=sdk_sandbox(self._sdk, request.sandbox),
        )
        self._remember_turn(request.thread_id, turn)
        await self._emit(
            {
                "method": "turn/started",
                "params": {
                    "threadId": request.thread_id,
                    "turn": turn_ref(turn),
                },
            }
        )
        self._start_stream_task(request.thread_id, turn)
        payload = turn_ref(turn)
        return CodexTurnResult(turn_id=id_of(turn), payload=payload)

    async def steer_turn(self, request: CodexSteerTurnRequest) -> CodexTurnResult:
        turn = self._turn_handle(
            thread_id=request.thread_id,
            turn_id=request.turn_id,
        )
        result = await turn.steer(request.content)
        payload = turn_action_result(result) or turn_ref(turn)
        return CodexTurnResult(turn_id=id_of(turn), payload=payload)

    async def interrupt_turn(
        self,
        request: CodexInterruptTurnRequest,
    ) -> CodexTurnResult:
        turn = self._turn_handle(
            thread_id=request.thread_id,
            turn_id=request.turn_id,
        )
        result = await turn.interrupt()
        payload = turn_action_result(result) or turn_ref(turn)
        return CodexTurnResult(turn_id=id_of(turn), payload=payload)

    async def compact_thread(self, thread_id: str) -> CodexCompactResult:
        await ensure_codex_initialized(self._client)
        # compact() only acknowledges scheduling; its turn has no SDK stream.
        # Observe before resume/start so even notifications preceding the ACK
        # reach the timeline instead of an unconsumed SDK turn queue.
        self._observe_command_thread(thread_id)
        low_level_client = codex_low_level_client(self._client)
        if low_level_client is not None:
            await self.ensure_thread_resumed(
                low_level_client,
                CodexResumeThreadRequest(thread_id=thread_id),
            )
        thread = self._thread_handle(thread_id)
        result = await thread.compact()
        return CodexCompactResult(payload=compact_result(result))

    async def ensure_thread_resumed(
        self,
        low_level_client: Any,
        request: CodexResumeThreadRequest,
    ) -> None:
        """Resume an existing Codex thread before a thread-scoped operation.

        Side effects:
        - sends thread/resume to the Codex app-server when this process has not
          loaded the thread yet
        - caches an AsyncThread handle for later thread-scoped operations
        """

        lock = self._resume_locks.setdefault(request.thread_id, asyncio.Lock())
        async with lock:
            await self._resume_thread(low_level_client, request)

    async def _persisted_thread_route(
        self, low_level_client: Any, thread_id: str
    ) -> tuple[str | None, str | None]:
        """The model and provider a thread last used, read without taking its writer lock."""
        read = getattr(low_level_client, "request", None)
        if not callable(read):
            return None, None
        try:
            result = await read(
                "thread/read",
                {"threadId": thread_id, "includeTurns": False},
                response_model=CodexRawThreadReadResponse,
            )
        except Exception:  # noqa: BLE001 -- resuming without it falls back to Codex's choice
            logger.exception("codex thread model read failed thread_id={}", thread_id)
            return None, None
        thread = result.thread
        if not isinstance(thread, Mapping):
            return None, None
        model = thread.get("model")
        provider = thread.get("modelProvider") or thread.get("model_provider")
        return (
            model if isinstance(model, str) and model else None,
            provider if isinstance(provider, str) and provider else None,
        )

    async def _resume_thread(
        self, low_level_client: Any, request: CodexResumeThreadRequest
    ) -> None:
        if request.thread_id in self._loaded_thread_ids:
            return
        thread_resume = getattr(low_level_client, "thread_resume", None)
        if not callable(thread_resume):
            return
        generation = self._generation
        model_gateway = self._model_gateway
        if model_gateway is not None:
            saved_model, saved_provider = await self._persisted_thread_route(
                low_level_client, request.thread_id
            )
            if saved_provider is not None and saved_provider != CODEX_MODEL_GATEWAY_PROVIDER_ID:
                # Threads from Codex itself (or created before the gateway was
                # configured) stay on their own provider; Codex refuses to move
                # a thread to another provider on resume.
                model_gateway = None
            elif request.model is None:
                # Passing the gateway provider makes Codex resume on config.toml's
                # model; keep the thread on the model it last used instead.
                request = replace(request, model=saved_model)
        try:
            params = codex_permission_params(
                codex_thread_resume_params(request, model_gateway),
                request.sandbox,
                "sandbox",
            )
            if getattr(low_level_client, "_sync", None) is not None:
                resumed = await low_level_client.request("thread/resume", params, response_model=CodexPlanningResumeResponse)
            else:
                resumed = await thread_resume(request.thread_id, params)
        except JsonRpcError as exc:
            if exc.code == -32600 and "already has an active writer" in exc.message:
                raise RuntimeConflictError(
                    "该 Codex 会话正由其他进程持有写入权限，AA 尚未接管。"
                    "请先在原 Codex 客户端释放该会话；若仍被占用，退出对应客户端后重试。"
                    "本次消息尚未发送。"
                ) from exc
            raise
        thread_id = resumed.thread.get("id") if isinstance(resumed.thread, dict) else id_of(resumed.thread)
        if generation != self._generation or thread_id != request.thread_id:
            raise RuntimeError("Codex thread resume identity or connection changed")
        collaboration = getattr(resumed, "collaboration_mode", None)
        if collaboration is not None:
            self._planning_modes[request.thread_id] = collaboration.model_dump(mode="json") if hasattr(collaboration, "model_dump") else dict(collaboration)
        self._thread_settings[request.thread_id] = {"model": getattr(resumed, "model", request.model), "reasoning_effort": getattr(resumed, "reasoning_effort", None)}
        thread = codex_async_thread(self._sdk, self._client, thread_id)
        if thread is not None:
            self._remember_thread(thread)
        if thread_id is not None:
            self._loaded_thread_ids.add(thread_id)

    async def planning_settings(self, thread_id: str) -> dict:
        await ensure_codex_initialized(self._client)
        low = codex_low_level_client(self._client)
        if low is None:
            raise RuntimeInvalidRequestError("Native planning settings are unavailable")
        await self._resume_thread(low, CodexResumeThreadRequest(thread_id=thread_id))
        return self._thread_settings.get(thread_id, {})

    async def set_collaboration_mode(self, thread_id: str, collaboration: dict) -> None:
        await ensure_codex_initialized(self._client)
        low = codex_low_level_client(self._client)
        if low is None:
            raise RuntimeInvalidRequestError("Native Plan controls require the Codex app-server interface")
        await self._resume_thread(low, CodexResumeThreadRequest(thread_id=thread_id))
        await low.request("thread/settings/update", {"threadId": thread_id, "collaborationMode": collaboration}, response_model=CodexSettingsUpdateResponse)
        self._planning_modes[thread_id] = collaboration

    def thread_loaded(self, thread_id: str) -> bool:
        """Whether this app-server generation started or resumed ``thread_id``.

        Only ``thread/start`` and ``thread/resume`` take the writer lock, so this
        is the positive evidence that the Connector holds the thread. Reads never
        load a thread.
        """

        return thread_id in self._loaded_thread_ids

    async def update_thread_settings(
        self, thread_id: str, settings: Mapping[str, Any]
    ) -> bool:
        """Apply settings to a thread this app-server holds, from its next turn on.

        Codex Desktop changes settings the same way, so a window following the
        thread shows the change at once instead of after AA's next message.

        Returns False when nothing was applied: the thread is not loaded here
        (loading it would take its writer lock) or app-server lacks the method.
        Raises when app-server rejects the settings.
        """

        if not settings or not self._thread_settings_update_supported:
            return False
        if thread_id not in self._loaded_thread_ids:
            return False
        request = await self._settings_request()
        if request is None:
            return False
        try:
            await request(
                "thread/settings/update",
                {"threadId": thread_id, **settings},
                response_model=CodexSettingsUpdateResponse,
            )
        except JsonRpcError as exc:
            if not codex_method_unsupported(exc):
                raise
            logger.info("codex app-server cannot update thread settings: {}", exc.message)
            self._thread_settings_update_supported = False
            return False
        return True

    async def update_turn_settings(
        self, thread_id: str, turn_id: str, settings: Mapping[str, Any]
    ) -> bool:
        """Apply settings to the running turn of a thread this app-server holds.

        app-server takes the reviewer, model and effort here; the sandbox and
        approval policy of a running turn cannot change.
        """

        if not settings or thread_id not in self._loaded_thread_ids:
            return False
        request = await self._settings_request()
        if request is None:
            return False
        await request(
            "turn/settings/update",
            {"threadId": thread_id, "turnId": turn_id, **settings},
            response_model=CodexSettingsUpdateResponse,
        )
        return True

    async def _settings_request(self) -> Callable[..., Awaitable[Any]] | None:
        await ensure_codex_initialized(self._client)
        request = getattr(codex_low_level_client(self._client), "request", None)
        return request if callable(request) else None

    def _observe_command_thread(self, thread_id: str) -> None:
        if self._command_notifications:
            ordinary = tuple(
                turn_id
                for turn_id in self._stream_tasks
                if (turn := self._turns.get(turn_id)) is not None
                and (
                    getattr(turn, "thread_id", None) == thread_id
                    or self._turns.get(thread_id) is turn
                )
            )
            self._command_notifications.enable(thread_id, ordinary)

    async def ensure_thread_resumed_for_turn(
        self,
        low_level_client: Any,
        request: CodexStartTurnRequest,
    ) -> None:
        """Resume an existing Codex thread before starting a turn.

        Side effects:
        - sends thread/resume to the Codex app-server when this process has not
          loaded the thread yet
        - caches an AsyncThread handle for later thread-scoped operations
        """

        await self.ensure_thread_resumed(
            low_level_client,
            CodexResumeThreadRequest(
                thread_id=request.thread_id,
                model=request.model,
                approval_policy=request.approval_policy,
                approvals_reviewer=request.approvals_reviewer,
                sandbox=request.sandbox,
            ),
        )

    async def start_low_level_turn_with_resume_retry(
        self,
        low_level_client: Any,
        request: CodexStartTurnRequest,
    ) -> Any:
        """Start a Codex turn, recovering once when the thread was not loaded.

        Side effects:
        - sends turn/start to Codex app-server
        - on thread-not-found, forces thread/resume and retries turn/start once
        """

        try:
            return await low_level_client.turn_start(
                request.thread_id,
                codex_turn_user_input_wire(request),
                params=codex_turn_start_payload(request),
            )
        except Exception as exc:
            if soft_codex_unavailable_reason(str(exc)) != "thread_not_found":
                raise
            self._loaded_thread_ids.discard(request.thread_id)
            await self.force_thread_resume_for_turn(low_level_client, request)
            return await low_level_client.turn_start(
                request.thread_id,
                codex_turn_user_input_wire(request),
                params=codex_turn_start_payload(request),
            )

    async def force_thread_resume_for_turn(
        self,
        low_level_client: Any,
        request: CodexStartTurnRequest,
    ) -> None:
        self._loaded_thread_ids.discard(request.thread_id)
        await self.ensure_thread_resumed_for_turn(low_level_client, request)

    async def respond(
        self,
        request_id: str | int,
        result: Mapping[str, Any] | None = None,
    ) -> None:
        response_payload = dict(result or {})
        request_key = str(request_id)
        pending_request = self._pending_approval_responses.pop(request_key, None)
        if pending_request is not None:
            if not pending_request.response.done():
                pending_request.response.set_result(response_payload)
            logger.info(
                "codex sdk approval response delivered request_id={} pending_hit=true payload_keys={}",
                request_key,
                sorted(response_payload.keys()),
            )
            return
        logger.warning(
            "codex sdk approval response has no pending request request_id={} pending_ids={} payload_keys={}",
            request_key,
            sorted(self._pending_approval_responses.keys()),
            sorted(response_payload.keys()),
        )
        respond = getattr(self._client, "respond", None)
        if not callable(respond):
            raise RuntimeInvalidRequestError(
                "Codex SDK client does not expose respond(request_id, result)"
            )
        await maybe_await(respond(request_id, response_payload))

    def handle_sdk_approval_request(
        self,
        method: str,
        params: Mapping[str, Any] | None,
    ) -> dict[str, Any]:
        if method in CODEX_SDK_INPUT_REQUEST_METHODS:
            return self.handle_sdk_input_request(method, dict(params or {}))
        if method not in CODEX_SDK_APPROVAL_REQUEST_METHODS:
            return {}
        loop = self._loop
        if loop is None:
            logger.warning(
                "codex sdk approval request declined because runtime loop is unavailable method={}",
                method,
            )
            return {"decision": "decline"}
        started_at = time.monotonic()
        future = asyncio.run_coroutine_threadsafe(
            self.publish_sdk_approval_request(method, dict(params or {})),
            loop,
        )
        response = dict(future.result())
        elapsed_ms = (time.monotonic() - started_at) * 1000
        logger.info(
            "codex sdk approval request completed method={} elapsed_ms={:.1f} response_keys={}",
            method,
            elapsed_ms,
            sorted(response.keys()),
        )
        return response

    async def publish_sdk_approval_request(
        self,
        method: str,
        params: dict[str, Any],
    ) -> Mapping[str, Any]:
        if self._handler is None:
            logger.warning(
                "codex sdk approval request declined because notification handler is unavailable method={}",
                method,
            )
            return {"decision": "decline"}
        request_id = sdk_approval_request_id(method, params)
        response: asyncio.Future[Mapping[str, Any]] = asyncio.Future()
        self._pending_approval_responses[request_id] = PendingServerRequest(
            kind="approval", response=response
        )
        logger.info(
            "codex sdk approval request registered method={} request_id={} approval_id={} thread_id={} turn_id={} item_id={}",
            method,
            request_id,
            approval_identifier(params),
            params.get("threadId") or params.get("thread_id"),
            params.get("turnId") or params.get("turn_id"),
            params.get("itemId") or params.get("item_id"),
        )
        try:
            await self._handler(
                {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "method": method,
                    "params": params,
                }
            )
            return await response
        finally:
            self._pending_approval_responses.pop(request_id, None)
            logger.debug(
                "codex sdk approval request unregistered request_id={} pending_count={}",
                request_id,
                len(self._pending_approval_responses),
            )

    def handle_sdk_input_request(
        self,
        method: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Answer one Codex `request_user_input` request with the user's answers.

        Runs on the SDK server-request reader thread. The runtime loop publishes
        the questionnaire notice and resolves the returned future once the user
        answers through `interaction.respond`.
        """

        loop = self._loop
        if loop is None:
            logger.warning(
                "codex sdk input request answered empty because runtime loop is unavailable method={} thread_id={} turn_id={}",
                method,
                params.get("threadId") or params.get("thread_id"),
                params.get("turnId") or params.get("turn_id"),
            )
            return {"answers": {}}
        started_at = time.monotonic()
        future = asyncio.run_coroutine_threadsafe(
            self.publish_sdk_input_request(method, params),
            loop,
        )
        response = dict(future.result())
        elapsed_ms = (time.monotonic() - started_at) * 1000
        logger.info(
            "codex sdk input request completed method={} elapsed_ms={:.1f} answer_count={}",
            method,
            elapsed_ms,
            len(response.get("answers") or {}),
        )
        return response

    async def publish_sdk_input_request(
        self,
        method: str,
        params: dict[str, Any],
    ) -> Mapping[str, Any]:
        if self._handler is None:
            logger.warning(
                "codex sdk input request answered empty because notification handler is unavailable method={}",
                method,
            )
            return {"answers": {}}
        request_id = sdk_input_request_id(method, params)
        response: asyncio.Future[Mapping[str, Any]] = asyncio.Future()
        self._pending_approval_responses[request_id] = PendingServerRequest(
            kind="input", response=response
        )
        logger.info(
            "codex sdk input request registered method={} request_id={} thread_id={} turn_id={} item_id={} question_count={} is_blocking={}",
            method,
            request_id,
            params.get("threadId") or params.get("thread_id"),
            params.get("turnId") or params.get("turn_id"),
            params.get("itemId") or params.get("item_id"),
            len(params.get("questions") or []),
            params.get("isBlocking"),
        )
        try:
            await self._handler(
                {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "method": method,
                    "params": params,
                }
            )
            return await response
        finally:
            self._pending_approval_responses.pop(request_id, None)
            logger.debug(
                "codex sdk input request unregistered request_id={} pending_count={}",
                request_id,
                len(self._pending_approval_responses),
            )

    def _thread_handle(self, thread_id: str) -> Any:
        cached = self._threads.get(thread_id)
        if cached is not None:
            return cached
        async_thread = (
            getattr(self._sdk, "AsyncThread", None) if self._sdk is not None else None
        )
        if callable(async_thread):
            thread = async_thread(self._client, thread_id)
            self._threads[thread_id] = thread
            return thread
        resume = getattr(self._client, "thread_resume", None)
        if callable(resume):
            raise RuntimeInvalidRequestError(
                "Codex SDK thread handle must be created before use"
            )
        raise RuntimeInvalidRequestError("Codex SDK does not expose AsyncThread")

    def _remember_thread(self, thread: Any) -> None:
        thread_id = id_of(thread)
        if thread_id is not None:
            self._threads[thread_id] = thread

    def _remember_turn(self, thread_id: str, turn: Any) -> None:
        turn_id = id_of(turn)
        if turn_id is not None:
            self._turns[turn_id] = turn
        self._turns[thread_id] = turn

    def _turn_handle(self, thread_id: str, turn_id: str | None) -> Any:
        if turn_id is not None:
            turn = self._turns.get(turn_id)
            if turn is None or getattr(turn, "thread_id", thread_id) != thread_id:
                raise RuntimeInvalidRequestError(
                    f"Codex SDK has no active turn {turn_id} for thread {thread_id}"
                )
            return turn
        turn = self._turns.get(thread_id)
        if turn is None:
            raise RuntimeInvalidRequestError(
                f"Codex SDK has no active turn for thread {thread_id}"
            )
        return turn

    def _start_stream_task(self, thread_id: str, turn: Any) -> None:
        if not callable(getattr(turn, "stream", None)) or self._handler is None:
            return
        turn_id = id_of(turn) or thread_id
        old_task = self._stream_tasks.pop(turn_id, None)
        if old_task is not None:
            old_task.cancel()
        stream_state = TurnStreamState(thread_id=thread_id, turn_id=turn_id)
        self._stream_states[turn_id] = stream_state
        task = asyncio.create_task(
            self._stream_turn(thread_id, turn_id, turn, stream_state=stream_state)
        )
        self._stream_tasks[turn_id] = task
        task.add_done_callback(self.handle_stream_task_done)

    def handle_stream_task_done(self, task: asyncio.Task[None]) -> None:
        try:
            task.result()
        except asyncio.CancelledError:
            logger.debug("codex sdk turn stream task cancelled")
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "codex sdk turn stream task failed error_type={}",
                type(exc).__name__,
            )

    async def _stream_turn(
        self,
        thread_id: str,
        turn_id: str,
        turn: Any,
        *,
        stream_state: TurnStreamState | None = None,
    ) -> None:
        stream_state = stream_state or TurnStreamState(thread_id, turn_id)
        completed_seen = False
        cancelled = False
        try:
            async for notification in turn.stream():
                message = CodexSdkEvent.from_value(
                    notification,
                    thread_id=thread_id,
                    turn_id=turn_id,
                )
                is_terminal = message.event_type in {
                    "turn/completed",
                    "turn/failed",
                    "turn/interrupted",
                    "turn/cancelled",
                }
                if is_terminal:
                    completed_seen = True
                    delivery = self._start_terminal_delivery(stream_state, message)
                    await asyncio.shield(delivery)
                else:
                    await self._emit(message)
        except asyncio.CancelledError:
            cancelled = True
            raise
        finally:
            try:
                if not completed_seen and not cancelled:
                    self._start_terminal_delivery(
                        stream_state,
                        {
                            "method": "turn/failed",
                            "params": {
                                "threadId": thread_id,
                                "turnId": turn_id,
                                "error": {
                                    "code": "codex_stream_ended_without_terminal_event",
                                    "message": "Codex stream ended without a terminal turn event.",
                                },
                                "metadata": {"source": "codex.sdk.stream.exhausted"},
                            },
                        },
                    )
                await self._finish_terminal_delivery(stream_state)
            finally:
                if self._stream_tasks.get(turn_id) is asyncio.current_task():
                    self._stream_tasks.pop(turn_id, None)
                if self._stream_states.get(turn_id) is stream_state:
                    self._stream_states.pop(turn_id, None)
                if self._turns.get(turn_id) is turn:
                    self._turns.pop(turn_id, None)
                if self._turns.get(thread_id) is turn:
                    self._turns.pop(thread_id, None)

    def _start_terminal_delivery(
        self, stream: TurnStreamState, message: CodexNotificationMessage
    ) -> asyncio.Task[None]:
        if stream.terminal_delivery is None:
            # The projector performs several awaited host writes. Give the whole
            # terminal one owner so stream cancellation cannot interrupt it.
            stream.terminal_delivery = asyncio.create_task(self._emit(message))
        return stream.terminal_delivery

    async def _finish_terminal_delivery(self, stream: TurnStreamState) -> None:
        delivery = stream.terminal_delivery
        if delivery is None:
            return
        cancelled = False
        while not delivery.done():
            try:
                await asyncio.shield(delivery)
            except asyncio.CancelledError:
                cancelled = True
            except Exception:  # noqa: BLE001
                break
        try:
            delivery.result()
        except asyncio.CancelledError:
            pass
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "codex terminal delivery failed thread_id={} turn_id={} error_type={}",
                stream.thread_id,
                stream.turn_id,
                type(exc).__name__,
            )
        if cancelled:
            raise asyncio.CancelledError

    async def _emit(self, message: CodexNotificationMessage) -> None:
        event = message if isinstance(message, CodexSdkEvent) else CodexSdkEvent.from_message(message)
        if event.event_type == "thread/settings/updated" and event.thread_id:
            collaboration = event.params.get("threadSettings", {}).get("collaborationMode")
            if isinstance(collaboration, dict):
                self._planning_modes[event.thread_id] = collaboration
        if self._stopping:
            return
        method, thread_id, turn_id = turn_identity(message)
        if thread_id and turn_id:
            if method == "turn/started":
                key = (thread_id, turn_id)
                if key in self._announced_turns:
                    return
                self._announced_turns.add(key)
                if turn_id not in self._turns:
                    turn = codex_async_turn_handle(
                        self._sdk, self._client, thread_id, turn_id
                    )
                    if turn is not None:
                        self._remember_turn(thread_id, turn)
            elif method in {
                "turn/completed",
                "turn/failed",
                "turn/interrupted",
                "turn/cancelled",
            }:
                self._announced_turns.discard((thread_id, turn_id))
                turn = self._turns.pop(turn_id, None)
                if turn is not None and self._turns.get(thread_id) is turn:
                    self._turns.pop(thread_id, None)
        if self._handler is not None:
            await self._handler(message)


def sdk_client_from_config(config: RuntimeConfig) -> CodexRuntimeClient:
    sdk = _load_codex_sdk()

    def create_client() -> Any:
        return _create_sdk_client(sdk, config)

    client = create_client()
    model_gateway = model_gateway_from_config(config.values.get("modelGateway"))
    return CodexSdkClient(
        client,
        sdk=sdk,
        model_gateway=model_gateway,
        client_factory=create_client,
    )


def is_codex_transport_closed_error(error: BaseException) -> bool:
    current: BaseException | None = error
    visited: set[int] = set()
    while current is not None and id(current) not in visited:
        visited.add(id(current))
        if isinstance(current, (ConnectionError, EOFError, TransportClosedError)):
            return True
        if isinstance(current, OSError) and current.errno in {
            errno.EBADF,
            errno.ECONNABORTED,
            errno.ECONNRESET,
            errno.EPIPE,
        }:
            return True
        if isinstance(current, ValueError) and "closed file" in str(current).lower():
            return True
        current = current.__cause__ or current.__context__
    return False


def _load_codex_sdk() -> Any:
    for module_name in ("openai_codex", "codex"):
        try:
            return importlib.import_module(module_name)
        except ImportError:
            continue
    raise RuntimeInvalidRequestError("Codex SDK package is not importable")


def _create_sdk_client(sdk: Any, config: RuntimeConfig) -> Any:
    async_codex = getattr(sdk, "AsyncCodex", None)
    if callable(async_codex):
        return async_codex(_sdk_config(sdk, config))
    for factory_name in ("create_runtime_client", "create_client", "Client", "Codex"):
        factory = getattr(sdk, factory_name, None)
        if not callable(factory):
            continue
        try:
            return factory(config=config)
        except TypeError:
            try:
                return factory(config.values)
            except TypeError:
                return factory()
    raise RuntimeInvalidRequestError(
        "Codex SDK does not expose a supported client factory"
    )


def _sdk_config(sdk: Any, config: RuntimeConfig) -> Any:
    config_cls = getattr(sdk, "CodexConfig", None)
    if not callable(config_cls):
        return None
    values = config.values
    environment_overrides = values.get("environment")
    use_system_codex = values.get("useSystemCodex", True)
    mode = "prefer_system" if use_system_codex is True else "sdk_bundled"
    environment = (
        environment_overrides if isinstance(environment_overrides, Mapping) else None
    )
    codex_home = values.get("codexHome")
    if isinstance(codex_home, str):
        runtime_environment, shell_path = codex_runtime_environment(
            environment,
            codex_home=codex_home,
        )
    else:
        runtime_environment, shell_path = codex_runtime_environment(environment)
    binary_selection = select_codex_runtime_binary(
        mode,
        runtime_environment,
        shell_path,
        configured_path=(
            values.get("codexExecutablePath")
            if isinstance(values.get("codexExecutablePath"), str)
            else None
        ),
        model_gateway=model_gateway_from_config(values.get("modelGateway")) is not None,
    )
    logger.info(
        "codex sdk runtime binary selected mode={} source={} codex_bin={} login_shell={}",
        binary_selection.mode,
        binary_selection.source,
        binary_selection.codex_bin,
        binary_selection.login_shell,
    )
    launch_options: dict[str, Any] = {}
    if binary_selection.codex_bin is not None:
        command = codex_launch_command(
            binary_selection.codex_bin,
            ["app-server", "--listen", "stdio://"],
            runtime_environment,
        )
        if command[0] != binary_selection.codex_bin:
            launch_options["launch_args_override"] = tuple(command)
    if "experimental_api" in inspect.signature(config_cls).parameters:
        launch_options["experimental_api"] = True
    return config_cls(
        **launch_options,
        codex_bin=binary_selection.codex_bin,
        env=runtime_environment,
        client_name="agents_anywhere_connector",
        client_title="Agents Anywhere Connector",
    )


async def ensure_codex_initialized(client: Any) -> None:
    ensure_initialized = getattr(client, "_ensure_initialized", None)
    if callable(ensure_initialized):
        await maybe_await(ensure_initialized())


def codex_low_level_client(client: Any) -> Any | None:
    candidate = getattr(client, "_client", None)
    if candidate is None:
        return None
    if not callable(getattr(candidate, "thread_start", None)):
        return None
    if not callable(getattr(candidate, "turn_start", None)):
        return None
    return candidate


def install_codex_approval_handler(client: Any, handler: Any) -> bool:
    nested_client = getattr(client, "_client", None)
    sync_client = getattr(nested_client, "_sync", None)
    if sync_client is not None and hasattr(sync_client, "_approval_handler"):
        sync_client._approval_handler = handler
        return True
    if hasattr(client, "_approval_handler"):
        client._approval_handler = handler
        return True
    return False


def sdk_input_request_id(method: str, params: Mapping[str, Any]) -> str:
    stable_parts = [
        method,
        str(params.get("threadId") or params.get("thread_id") or ""),
        str(params.get("turnId") or params.get("turn_id") or ""),
        str(params.get("itemId") or params.get("item_id") or ""),
    ]
    digest = hashlib.sha256(":".join(stable_parts).encode()).hexdigest()[:24]
    return f"input_{digest}"


def sdk_approval_request_id(method: str, params: Mapping[str, Any]) -> str:
    for key in ("approvalId", "approval_id", "requestId", "request_id"):
        value = params.get(key)
        if isinstance(value, str | int) and str(value):
            return f"approval_{value}"
    stable_parts = [
        method,
        str(params.get("threadId") or params.get("thread_id") or ""),
        str(params.get("turnId") or params.get("turn_id") or ""),
        str(params.get("itemId") or params.get("item_id") or ""),
        str(params.get("command") or params.get("cmd") or ""),
    ]
    digest = hashlib.sha256(":".join(stable_parts).encode()).hexdigest()[:24]
    return f"approval_{digest}"


def approval_identifier(params: Mapping[str, Any]) -> str | int | None:
    for key in ("approvalId", "approval_id", "requestId", "request_id"):
        value = params.get(key)
        if isinstance(value, str | int) and str(value):
            return value
    return None


def codex_request_requires_low_level_turn_start(
    request: CodexStartTurnRequest,
) -> bool:
    return (
        request.approval_policy is not None
        or request.approvals_reviewer is not None
        or len(request.attachments) > 0
    )


def codex_request_requires_low_level_approval(
    request: CodexStartThreadRequest | CodexStartTurnRequest,
) -> bool:
    return request.approval_policy is not None or request.approvals_reviewer is not None


def codex_low_level_turn_start_required_message(
    request: CodexStartTurnRequest,
) -> str:
    if request.attachments:
        return "Codex low-level client is required for typed attachment input"
    return "Codex low-level client is required for explicit approval settings"


def codex_thread_start_params(
    request: CodexStartThreadRequest,
    model_gateway: ModelGateway | None = None,
) -> ThreadStartParams:
    approval_policy, approvals_reviewer = codex_approval_settings(
        request.approval_policy,
        request.approvals_reviewer,
    )
    return ThreadStartParams(
        approvalPolicy=approval_policy,
        approvalsReviewer=approvals_reviewer,
        cwd=request.cwd,
        ephemeral=request.ephemeral,
        config=(
            codex_model_gateway_config(model_gateway)
            if model_gateway is not None
            else None
        ),
        model=request.model,
        modelProvider=(
            CODEX_MODEL_GATEWAY_PROVIDER_ID if model_gateway is not None else None
        ),
        sandbox=codex_thread_sandbox_mode(request.sandbox),
    )


def codex_thread_resume_params(
    request: CodexResumeThreadRequest | CodexStartTurnRequest,
    model_gateway: ModelGateway | None = None,
) -> ThreadResumeParams:
    approval_policy, approvals_reviewer = codex_approval_settings(
        request.approval_policy,
        request.approvals_reviewer,
    )
    return ThreadResumeParams(
        approvalPolicy=approval_policy,
        approvalsReviewer=approvals_reviewer,
        config=(
            codex_model_gateway_config(model_gateway)
            if model_gateway is not None
            else None
        ),
        model=request.model,
        modelProvider=(
            CODEX_MODEL_GATEWAY_PROVIDER_ID if model_gateway is not None else None
        ),
        sandbox=codex_thread_sandbox_mode(request.sandbox),
        threadId=request.thread_id,
    )


def codex_permission_params(
    params: BaseModel, sandbox: str | None, sandbox_field: str
) -> dict[str, Any]:
    """Serialize typed params, selecting the permission profile by name.

    The SDK models have no ``permissions`` field, but app-server accepts it on
    thread/start, thread/resume and turn/start from 0.144.4 on. A named profile keeps
    the thread's ``activePermissionProfile``; the legacy sandbox fields clear it,
    and Codex Desktop then shows the wrong permission mode. The two cannot be
    combined.
    """

    payload = params.model_dump(by_alias=True, exclude_none=True, mode="json")
    profile = permission_profile_id(sandbox)
    if profile is not None:
        payload.pop(sandbox_field, None)
        payload["permissions"] = profile
    return payload


def codex_method_unsupported(exc: JsonRpcError) -> bool:
    """Whether app-server rejected a request because it lacks the method."""

    if isinstance(exc, MethodNotFoundError):
        return True
    message = exc.message or ""
    return exc.code == -32600 and (
        "unknown variant" in message or "requires experimentalApi" in message
    )


def codex_turn_start_params(request: CodexStartTurnRequest) -> TurnStartParams:
    approval_policy, approvals_reviewer = codex_approval_settings(
        request.approval_policy,
        request.approvals_reviewer,
    )
    params = TurnStartParams(
        approvalPolicy=approval_policy,
        approvalsReviewer=approvals_reviewer,
        clientUserMessageId=request.client_message_id,
        effort=codex_reasoning_effort(request.effort),
        input=codex_turn_user_input(request),
        model=request.model,
        sandboxPolicy=codex_turn_sandbox_policy(request.sandbox),
        threadId=request.thread_id,
    )
    return params


def codex_turn_start_payload(request: CodexStartTurnRequest) -> dict[str, Any]:
    """turn/start params with the permission profile and native Plan mode applied."""

    payload = codex_permission_params(codex_turn_start_params(request), request.sandbox, "sandboxPolicy")
    if request.collaboration_mode is not None:
        payload["collaborationMode"] = request.collaboration_mode
    return payload


def codex_turn_user_input(request: CodexStartTurnRequest) -> list[UserInput]:
    values: list[UserInput] = [
        UserInput(
            root=TextUserInput(
                text=codex_turn_text_input(request),
                type="text",
            )
        )
    ]
    for attachment in request.attachments:
        if attachment.is_image:
            values.append(
                UserInput(
                    root=LocalImageUserInput(
                        path=attachment.path,
                        type="localImage",
                    )
                )
            )
            continue
    return values


def codex_turn_text_input(request: CodexStartTurnRequest) -> str:
    notes = [
        attachment.reference_note()
        for attachment in request.attachments
        if not attachment.is_image
    ]
    if not notes:
        return request.content
    return "\n\n".join([request.content, *notes])


def codex_turn_user_input_wire(request: CodexStartTurnRequest) -> list[dict[str, Any]]:
    return [
        item.model_dump(
            by_alias=True,
            exclude_defaults=True,
            exclude_none=True,
            mode="json",
        )
        for item in codex_turn_user_input(request)
    ]


def codex_high_level_turn_content(request: CodexStartTurnRequest) -> str:
    if not request.attachments:
        return request.content
    return "\n\n".join([request.content, codex_attachment_input_note(request)])


def codex_attachment_input_note(request: CodexStartTurnRequest) -> str:
    lines = [
        attachment.reference_note()
        for attachment in request.attachments
        if not attachment.is_image
    ]
    return "\n".join(lines)


def codex_approval_settings(
    approval_policy: str | None,
    approvals_reviewer: str | None = None,
) -> CodexApprovalSettings:
    if approval_policy in {"request_approval", "on-request", "on_request"}:
        return (
            AskForApproval(root=AskForApprovalValue.on_request),
            codex_approvals_reviewer(approvals_reviewer) or ApprovalsReviewer.user,
        )
    if approval_policy in {"untrusted", "ask_untrusted"}:
        return AskForApproval(
            root=AskForApprovalValue.untrusted
        ), ApprovalsReviewer.user
    if approval_policy in {"auto_review", "auto-review"}:
        return (
            AskForApproval(root=AskForApprovalValue.on_request),
            ApprovalsReviewer.auto_review,
        )
    if approval_policy in {"full_access", "never", "deny_all", "deny-all"}:
        return AskForApproval(root=AskForApprovalValue.never), None
    return None, None


def codex_approvals_reviewer(value: str | None) -> ApprovalsReviewer | None:
    if value in {"user", "request_approval"}:
        return ApprovalsReviewer.user
    if value in {"auto_review", "auto-review"}:
        return ApprovalsReviewer.auto_review
    if value in {"guardian_subagent", "guardian-subagent"}:
        return ApprovalsReviewer.guardian_subagent
    return None


def codex_thread_sandbox_mode(value: str | None) -> SandboxMode | None:
    if value in {"read-only", "read_only"}:
        return SandboxMode.read_only
    if value in {"workspace-write", "workspace_write"}:
        return SandboxMode.workspace_write
    if value in {"danger-full-access", "full-access", "full_access"}:
        return SandboxMode.danger_full_access
    return None


def codex_turn_sandbox_policy(value: str | None) -> SandboxPolicy | None:
    if value in {"read-only", "read_only"}:
        return SandboxPolicy(root=ReadOnlySandboxPolicy(type="readOnly"))
    if value in {"workspace-write", "workspace_write"}:
        return SandboxPolicy(root=WorkspaceWriteSandboxPolicy(type="workspaceWrite"))
    if value in {"danger-full-access", "full-access", "full_access"}:
        return SandboxPolicy(
            root=DangerFullAccessSandboxPolicy(type="dangerFullAccess")
        )
    return None


def codex_reasoning_effort(value: str | None) -> ReasoningEffort | None:
    if value == "none":
        return ReasoningEffort.none
    if value == "minimal":
        return ReasoningEffort.minimal
    if value == "low":
        return ReasoningEffort.low
    if value == "medium":
        return ReasoningEffort.medium
    if value == "high":
        return ReasoningEffort.high
    if value == "xhigh":
        return ReasoningEffort.xhigh
    return None


def codex_async_thread(
    sdk: Any | None, client: Any, thread_id: str | None
) -> Any | None:
    if thread_id is None:
        return None
    async_thread = getattr(sdk, "AsyncThread", None) if sdk is not None else None
    if not callable(async_thread):
        return None
    return async_thread(client, thread_id)


def codex_async_turn_handle(
    sdk: Any | None,
    client: Any,
    thread_id: str,
    turn_id: str | None,
) -> Any | None:
    if turn_id is None:
        return None
    low_level = getattr(client, "_client", None)
    if all(
        callable(getattr(low_level, method, None))
        for method in (
            "turn_interrupt",
            "turn_steer",
            "register_turn_notifications",
            "next_turn_notification",
            "unregister_turn_notifications",
        )
    ):
        return LowLevelTurnHandle(low_level, thread_id, turn_id)
    async_turn_handle = (
        getattr(sdk, "AsyncTurnHandle", None) if sdk is not None else None
    )
    if not callable(async_turn_handle):
        return None
    return async_turn_handle(client, thread_id, turn_id)
